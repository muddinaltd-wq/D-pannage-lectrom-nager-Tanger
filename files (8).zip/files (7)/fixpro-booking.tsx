"use client";
/**
 * FixPro Appliance Care — multi-step booking form + floating WhatsApp widget.
 * French / Arabic (RTL). React + Tailwind (3.3+), react-hook-form, zod, lucide-react.
 *
 *   npm i react-hook-form zod @hookform/resolvers lucide-react
 *
 * Usage (e.g. app/page.tsx, with `lang` coming from your own state/route):
 *   <BookingForm lang="fr" />
 *   <WhatsAppWidget lang="fr" />
 */
import { useState, type ReactNode } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { MessageCircle, X, ChevronLeft, ChevronRight, Check } from "lucide-react";

/* ───────── Config ───────── */
const PHONE = "212628535322"; // international format, no "+" or spaces
export type Lang = "fr" | "ar";
type Pair = readonly [string, string];
const L = (lang: Lang) => (lang === "ar" ? 1 : 0);

/* ───────── Data (FR, AR) ───────── */
const APPLIANCES: Pair[] = [["Réfrigérateur", "ثلاجة"], ["Lave-linge", "غسالة"], ["Climatisation", "مكيف"], ["Lave-vaisselle", "غسالة صحون"], ["Four / cuisinière", "فرن / موقد"], ["Micro-ondes", "ميكروويف"]];
const BRANDS: Pair[] = [["Samsung", "Samsung"], ["LG", "LG"], ["Bosch", "Bosch"], ["Whirlpool", "Whirlpool"], ["GE", "GE"], ["Autre", "أخرى"]];
const SERVICES: Pair[] = [["Réparation d'urgence", "إصلاح طارئ"], ["Entretien programmé", "صيانة دورية"], ["Installation / désinstallation", "تركيب / فك"], ["Diagnostic", "فحص وتشخيص"]];
const CHIPS: Pair[] = [["Aucune alimentation", "لا يعمل"], ["Bruit anormal", "صوت غريب"], ["Fuite d'eau", "تسرب مياه"], ["Ne refroidit/chauffe pas", "لا يبرّد/لا يسخّن"]];
const SLOTS: Pair[] = [["Matin (8h–12h)", "صباحاً (8–12)"], ["Après-midi (12h–17h)", "بعد الظهر (12–17)"], ["Soir (17h–20h)", "مساءً (17–20)"]];

const T = {
  fr: {
    steps: ["Appareil", "Besoin", "Rendez-vous", "Envoi"],
    appliance: "Appareil", brand: "Marque", service: "Type de service", issue: "Problème rencontré", issuePh: "Décrivez le problème (facultatif)",
    date: "Date souhaitée", slot: "Créneau", name: "Nom complet", phone: "Téléphone", address: "Adresse à Tanger (quartier, rue)",
    next: "Suivant", back: "Retour", instant: "Réservation instantanée sur WhatsApp", send: "Envoyer la demande (copie sur WhatsApp)",
    done: "Demande enregistrée. Une copie a été ouverte sur WhatsApp.", errName: "Nom requis", errPhone: "Numéro invalide", errAddr: "Adresse requise",
    chat: { title: "FixPro Tanger — Concierge", status: "En ligne · répond en 3 minutes", hello: "Bonjour ! Comment pouvons-nous vous aider ?", open: "Ouvrir le chat WhatsApp",
      q: ["J'ai une urgence électroménager", "Je veux un devis d'installation", "Techniciens disponibles aujourd'hui ?", "Parler à un responsable"] },
  },
  ar: {
    steps: ["الجهاز", "الحاجة", "الموعد", "الإرسال"],
    appliance: "الجهاز", brand: "العلامة التجارية", service: "نوع الخدمة", issue: "المشكلة", issuePh: "صف المشكلة (اختياري)",
    date: "التاريخ المفضل", slot: "الفترة", name: "الاسم الكامل", phone: "الهاتف", address: "العنوان في طنجة (الحي، الشارع)",
    next: "التالي", back: "رجوع", instant: "حجز فوري عبر واتساب", send: "إرسال الطلب (نسخة عبر واتساب)",
    done: "تم تسجيل الطلب. فُتحت نسخة على واتساب.", errName: "الاسم مطلوب", errPhone: "رقم غير صالح", errAddr: "العنوان مطلوب",
    chat: { title: "FixPro Tanger — خدمة العملاء", status: "متصل · يرد خلال 3 دقائق", hello: "مرحباً! كيف يمكننا مساعدتك؟", open: "فتح محادثة واتساب",
      q: ["لدي حالة طارئة مع جهازي", "أريد عرض سعر للتركيب", "هل الفنيون متاحون اليوم؟", "التحدث مع مسؤول الخدمة"] },
  },
} as const;

const MSG = {
  fr: { hello: "Bonjour l'équipe FixPro Tanger ! 🛠️", intro: "Je souhaite réserver une intervention à Tanger :", appliance: "Appareil", brand: "Marque", service: "Service", issue: "Problème", date: "Date souhaitée", address: "Adresse", contact: "Contact", none: "Non précisé", repair: "Réparation", diag: "À diagnostiquer", earliest: "Au plus tôt", later: "Je donnerai l'adresse dans la discussion", close: "Merci de m'indiquer le prix estimé et la disponibilité d'un technicien." },
  ar: { hello: "مرحباً فريق FixPro Tanger! 🛠️", intro: "أرغب في حجز خدمة في طنجة:", appliance: "الجهاز", brand: "العلامة التجارية", service: "الخدمة", issue: "المشكلة", date: "التاريخ المفضل", address: "العنوان", contact: "التواصل", none: "غير محدد", repair: "إصلاح", diag: "يحتاج تشخيصاً", earliest: "أقرب وقت", later: "سأرسل العنوان في المحادثة", close: "يرجى تزويدي بالسعر التقديري وتوفر الفني." },
} as const;

/* ───────── WhatsApp deep link (fixed version of the spec's builder) ───────── */
export type LinkInput = { phone?: string; lang?: Lang; appliance?: string; brand?: string; serviceType?: string; issue?: string; address?: string; date?: string; contact?: string };

export const generateWhatsAppLink = ({ phone = PHONE, lang = "fr", appliance, brand, serviceType, issue, address, date, contact }: LinkInput) => {
  const m = MSG[lang];
  const text = encodeURIComponent(
    `${m.hello}\n\n${m.intro}\n` +
      `• ${m.appliance}: ${appliance || m.none}\n` +
      `• ${m.brand}: ${brand || m.none}\n` +
      `• ${m.service}: ${serviceType || m.repair}\n` +
      `• ${m.issue}: ${issue || m.diag}\n` +
      `• ${m.date}: ${date || m.earliest}\n` +
      `• ${m.address}: ${address || m.later}\n` +
      (contact ? `• ${m.contact}: ${contact}\n` : "") +
      `\n${m.close}`
  );
  return `https://wa.me/${phone}?text=${text}`;
};

/* ───────── Validation (zod) ───────── */
const schema = z.object({
  appliance: z.number().int().min(0),
  brand: z.number().int().min(0),
  service: z.number().int().min(0),
  chips: z.array(z.number()),
  issue: z.string().max(500).optional(),
  date: z.string().optional(),
  slot: z.number().int().min(0),
  name: z.string().trim().min(2, "name"),
  phone: z.string().trim().regex(/^\+?[0-9\s-]{8,16}$/, "phone"),
  address: z.string().trim().min(3, "address"),
});
type Values = z.infer<typeof schema>;
const STEP_FIELDS: (keyof Values)[][] = [[], [], ["name", "phone", "address"], []];

/* ───────── UI helpers ───────── */
const inp = "h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-600/20 dark:border-slate-700 dark:bg-slate-900";

function Field({ label, error, children }: { label: string; error?: string; children: ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="text-sm font-medium">{label}</span>
      {children}
      {error && <span className="block text-xs text-red-600">{error}</span>}
    </label>
  );
}

function Chips({ items, value, onChange, lang, cols = "grid-cols-2" }: { items: readonly Pair[]; value: number | number[]; onChange: (n: number) => void; lang: Lang; cols?: string }) {
  const on = (n: number) => (Array.isArray(value) ? value.includes(n) : value === n);
  return (
    <div className={`grid gap-2 ${cols}`}>
      {items.map((p, n) => (
        <button
          key={n}
          type="button"
          aria-pressed={on(n)}
          onClick={() => onChange(n)}
          className={`min-h-11 rounded-xl border px-3 text-sm font-medium transition-all duration-300 hover:-translate-y-0.5 hover:shadow-md ${
            on(n) ? "border-blue-600 bg-blue-600/10 text-blue-700 dark:text-blue-300" : "border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-900"
          }`}
        >
          {p[L(lang)]}
        </button>
      ))}
    </div>
  );
}

/* ───────── Multi-step booking form ───────── */
export function BookingForm({ lang = "fr", onSubmitOrder }: { lang?: Lang; onSubmitOrder?: (order: unknown) => Promise<unknown> | void }) {
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);
  const i = L(lang);
  const t = T[lang];
  const { register, handleSubmit, setValue, watch, trigger, formState: { errors } } = useForm<Values>({
    resolver: zodResolver(schema),
    mode: "onTouched",
    defaultValues: { appliance: 0, brand: 0, service: 0, chips: [], issue: "", date: "", slot: 0, name: "", phone: "", address: "" },
  });
  const v = watch();
  const set = <K extends keyof Values>(k: K, val: Values[K]) => setValue(k, val, { shouldValidate: true });
  const err = (e?: { message?: string }) => (e?.message === "name" ? t.errName : e?.message === "phone" ? t.errPhone : e?.message === "address" ? t.errAddr : undefined);

  const link = (d: Values) =>
    generateWhatsAppLink({
      lang,
      appliance: APPLIANCES[d.appliance][i],
      brand: BRANDS[d.brand][i],
      serviceType: SERVICES[d.service][i],
      issue: [...d.chips.map((c) => CHIPS[c][i]), d.issue?.trim()].filter(Boolean).join(", "),
      date: [d.date, SLOTS[d.slot][i]].filter(Boolean).join(" · "),
      address: d.address,
      contact: `${d.name} ${d.phone}`,
    });

  const next = async () => {
    if (await trigger(STEP_FIELDS[step])) setStep((s) => s + 1);
  };

  const instant = handleSubmit((d) => {
    window.open(link(d), "_blank", "noopener");
  });

  const standard = handleSubmit((d) => {
    window.open(link(d), "_blank", "noopener"); // open first so popup blockers allow it
    const post = onSubmitOrder ?? ((o: unknown) => fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(o) }));
    Promise.resolve(post({ ...d, lang, createdAt: new Date().toISOString() })).catch(() => {});
    setDone(true);
  });

  return (
    <div dir={lang === "ar" ? "rtl" : "ltr"} className="mx-auto w-full max-w-xl rounded-2xl border border-slate-200/60 bg-white/80 p-6 shadow-sm backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/80">
      <ol className="mb-6 grid grid-cols-4 gap-2">
        {t.steps.map((s, n) => (
          <li key={s} className="space-y-1">
            <div className={`h-1.5 rounded-full transition-colors duration-300 ${n <= step ? "bg-blue-600" : "bg-slate-200 dark:bg-slate-700"}`} />
            <span className={`block text-xs ${n === step ? "font-semibold" : "text-slate-500"}`}>{s}</span>
          </li>
        ))}
      </ol>

      <form onSubmit={(e) => e.preventDefault()} className="space-y-5">
        {step === 0 && (
          <>
            <Field label={t.appliance}><Chips lang={lang} items={APPLIANCES} value={v.appliance} onChange={(n) => set("appliance", n)} cols="grid-cols-2 sm:grid-cols-3" /></Field>
            <Field label={t.brand}><Chips lang={lang} items={BRANDS} value={v.brand} onChange={(n) => set("brand", n)} cols="grid-cols-3" /></Field>
          </>
        )}

        {step === 1 && (
          <>
            <Field label={t.service}><Chips lang={lang} items={SERVICES} value={v.service} onChange={(n) => set("service", n)} /></Field>
            <Field label={t.issue}>
              <Chips lang={lang} items={CHIPS} value={v.chips} onChange={(n) => set("chips", v.chips.includes(n) ? v.chips.filter((c) => c !== n) : [...v.chips, n])} />
            </Field>
            <textarea {...register("issue")} rows={3} placeholder={t.issuePh} className={`${inp} h-auto py-2`} />
          </>
        )}

        {step === 2 && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={t.date}><input type="date" min={new Date().toISOString().slice(0, 10)} {...register("date")} className={inp} /></Field>
            <Field label={t.slot}>
              <select value={v.slot} onChange={(e) => set("slot", Number(e.target.value))} className={inp}>
                {SLOTS.map((s, n) => <option key={n} value={n}>{s[i]}</option>)}
              </select>
            </Field>
            <Field label={t.name} error={err(errors.name)}><input autoComplete="name" {...register("name")} className={inp} /></Field>
            <Field label={t.phone} error={err(errors.phone)}><input type="tel" dir="ltr" autoComplete="tel" {...register("phone")} className={inp} /></Field>
            <div className="sm:col-span-2"><Field label={t.address} error={err(errors.address)}><input autoComplete="street-address" {...register("address")} className={inp} /></Field></div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-3">
            <div className="rounded-xl border border-slate-200 bg-blue-600/5 p-4 text-sm dark:border-slate-700">
              <b>{APPLIANCES[v.appliance][i]}</b> · {BRANDS[v.brand][i]}<br />
              {SERVICES[v.service][i]}{v.chips.length ? ` — ${v.chips.map((c) => CHIPS[c][i]).join(", ")}` : ""}<br />
              {[v.date, SLOTS[v.slot][i]].filter(Boolean).join(" · ")} · {v.name} · <span dir="ltr">{v.phone}</span>
            </div>
            <button type="button" onClick={instant} className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#25D366] px-4 text-sm font-semibold text-white transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg">
              <MessageCircle className="h-4 w-4" /> {t.instant}
            </button>
            <button type="button" onClick={standard} className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg">
              <Check className="h-4 w-4" /> {t.send}
            </button>
            {done && <p role="status" className="text-sm text-emerald-600">{t.done}</p>}
          </div>
        )}

        <div className="flex justify-between pt-1">
          <button type="button" onClick={() => setStep((s) => s - 1)} className={`inline-flex min-h-11 items-center gap-1 rounded-xl border border-slate-200 px-4 text-sm font-medium dark:border-slate-700 ${step ? "" : "invisible"}`}>
            <ChevronLeft className="h-4 w-4 rtl:rotate-180" /> {t.back}
          </button>
          {step < 3 && (
            <button type="button" onClick={next} className="inline-flex min-h-11 items-center gap-1 rounded-xl bg-blue-600 px-5 text-sm font-semibold text-white transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg">
              {t.next} <ChevronRight className="h-4 w-4 rtl:rotate-180" />
            </button>
          )}
        </div>
      </form>
    </div>
  );
}

/* ───────── Floating WhatsApp concierge ───────── */
export function WhatsAppWidget({ lang = "fr" }: { lang?: Lang }) {
  const [open, setOpen] = useState(false);
  const c = T[lang].chat;
  const icons = ["⚡", "🛠️", "📅", "💬"];
  const href = (text: string) => `https://wa.me/${PHONE}?text=${encodeURIComponent(text)}`;

  return (
    <div dir={lang === "ar" ? "rtl" : "ltr"} className="fixed bottom-5 end-5 z-50">
      {open && (
        <div className="absolute bottom-[4.5rem] end-0 w-[min(20.5rem,calc(100vw-2.5rem))] overflow-hidden rounded-2xl border border-slate-200/60 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-3 bg-[#25D366] p-4 text-white">
            <span className="grid h-10 w-10 place-items-center rounded-full bg-white/20 text-xl">👨‍🔧</span>
            <div className="flex-1">
              <p className="text-sm font-semibold">{c.title}</p>
              <p className="flex items-center gap-1.5 text-xs"><span className="h-2 w-2 animate-pulse rounded-full bg-white" />{c.status}</p>
            </div>
            <button type="button" aria-label="Close" onClick={() => setOpen(false)} className="grid h-8 w-8 place-items-center rounded-full hover:bg-white/20"><X className="h-4 w-4" /></button>
          </div>
          <div className="space-y-2 p-4">
            <p className="rounded-xl bg-slate-100 p-3 text-sm dark:bg-slate-800">{c.hello}</p>
            {c.q.map((text, n) => (
              <a key={n} href={href(`${icons[n]} ${text}`)} target="_blank" rel="noopener noreferrer"
                className="flex min-h-11 items-center gap-2 rounded-xl border border-slate-200 px-3 text-sm font-medium transition-all duration-300 hover:-translate-y-0.5 hover:border-[#25D366] hover:shadow-md dark:border-slate-700">
                <span>{icons[n]}</span>{text}
              </a>
            ))}
          </div>
        </div>
      )}
      <button type="button" aria-label={c.open} aria-expanded={open} onClick={() => setOpen((o) => !o)}
        className="grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-lg shadow-emerald-500/40 transition-transform duration-300 hover:scale-110">
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </button>
    </div>
  );
}
